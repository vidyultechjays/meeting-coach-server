document.addEventListener('DOMContentLoaded', () => {
  // Persona chosen: "Senior Web Audio Engineer"
  // This persona focuses on reliable audio processing, clean architecture, and robust error handling.

  const startButton = document.getElementById('startCapture');
  const stopButton = document.getElementById('stopCapture');
  const startRecordingButton = document.getElementById('startRecording');
  const stopRecordingButton = document.getElementById('stopRecording');
  const status = document.getElementById('status');
  const inputMeter = document.getElementById('inputMeter');
  const recordingTime = document.getElementById('recordingTime');
  const recordingsContainer = document.getElementById('recordings');
  const transcriptionText = document.getElementById('transcriptionText');
  const meetingAgenda = document.getElementById('meetingAgenda');
  const saveAgendaButton = document.getElementById('saveAgenda');
  const copilotInput = document.getElementById('copilotInput');
  const coachButton = document.getElementById('coachButton');
  const coachingResponses = document.getElementById('coachingResponses');
  

  let userEmail = null;
  let mediaStream = null;
  let audioContext = null;
  let mediaRecorder = null;
  let analyzerInterval = null;

  let transcriptionInterval = null;  // New interval for auto-transcription

  // Accumulate chunks until we have a good amount for a stable decode
  let accumulatedChunks = [];
  let isTranscribing = false;
  let recordingStartTime = null;
  let transcriptionIntervalId = null;

  TRANSCRIPTION_INTERVAL = 30000
  TIMEOUT_TIME = 5000

  const ALLOWED_DOMAIN = 'techjays.com';
  const UNAUTHORIZED_MESSAGE = 'Only Techjays employees are authorized to use this extension';
  
  const signInButton = document.getElementById('signInButton');
  const signOutButton = document.getElementById('signOutButton');
  const userInfoDiv = document.getElementById('userInfo');
  const userEmailSpan = document.getElementById('userEmail');
  let userInfo = null;
  

  let micStream = null; // Separate reference for mic stream
  let systemStream = null; // Separate reference for system stream
  let isMicMuted = false; // Track mic mute state

  let systemRecorder = null;
  let micRecorder = null;
  
  // Add listener for mute state changes from background script
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === 'meetMuteState') {
      console.log('Received mute state:', request.isMuted);
      isMicMuted = request.isMuted;
      handleMuteStateChange(request.isMuted);
    }
  });

// Add these variables at the top
let lastProcessTime = Date.now();
let pendingMicChunks = [];  // Buffer for storing chunks between intervals

// Modify handleMuteStateChange function
async function handleMuteStateChange(isMuted) {
    console.log('Mute state change handler called:', { isMuted, hasMediaRecorder: !!mediaRecorder, hasMicRecorder: !!mediaRecorder?.mic });
    if (!mediaRecorder || !mediaRecorder.mic) return;
    
    if (isMuted) {
        // If we have pending chunks when muting, process them
        if (pendingMicChunks.length > 0) {
            console.log('Processing pending chunks before mute');
            const micBlob = new Blob(pendingMicChunks, { type: 'audio/webm' });
            if (micBlob.size > 0) {
                await processSeparateStreams(pendingMicChunks, []);
                pendingMicChunks = [];
            }
        }
        
        // Stop mic recorder
        if (mediaRecorder.mic.state === 'recording') {
            mediaRecorder.mic.stop();
            showStatus('Microphone muted - paused mic recording', 'capture');
        }
        
        // Stop mic tracks
        if (micStream) {
            micStream.getTracks().forEach(track => track.enabled = false);
        }
    } else {
        // Resume mic recording if system is still recording
        if (mediaRecorder.mic.state === 'inactive' && mediaRecorder.system.state === 'recording') {
            // Create new MediaRecorder for mic
            const newMicRecorder = new MediaRecorder(micStream, {
                mimeType: 'audio/webm',
                audioBitsPerSecond: 128000
            });
            
            // Set up data handling for new chunks after unmute
            newMicRecorder.ondataavailable = (e) => {
                console.log('Mic data available after unmute:', e.data.size);
                if (e.data && e.data.size > 0) {
                    pendingMicChunks.push(e.data);
                    
                    // If we have accumulated enough data, process it
                    const currentBlob = new Blob(pendingMicChunks, { type: 'audio/webm' });
                    if (currentBlob.size > MINIMUM_AUDIO_SIZE) {
                        console.log('Processing accumulated chunks after unmute');
                        processSeparateStreams(pendingMicChunks, []).then(() => {
                            pendingMicChunks = [];
                        });
                    }
                }
            };
            
            // Update the reference
            mediaRecorder.mic = newMicRecorder;
            mediaRecorder.mic.start();
            
            // Enable mic tracks
            micStream.getTracks().forEach(track => track.enabled = true);
            
            // Reset timing
            lastProcessTime = Date.now();
            
            showStatus('Microphone unmuted - resumed mic recording', 'capture');
        }
    }
}

  // Modify the transcription interval in startCapture
  transcriptionInterval = setInterval(async () => {
      if (systemRecorder && systemRecorder.state === 'recording') {
          // Always stop system recorder
          systemRecorder.stop();
          
          // Only stop mic recorder if it's currently recording
          if (micRecorder && micRecorder.state === 'recording' && !isMicMuted) {
              micRecorder.stop();
          }

          // Process both streams
          setTimeout(async () => {
              const currentTime = Date.now();
              const timeSinceLastProcess = currentTime - lastProcessTime;

              // Process any pending mic chunks first
              if (pendingMicChunks.length > 0) {
                  const pendingBlob = new Blob(pendingMicChunks, { type: 'audio/webm' });
                  if (pendingBlob.size > 0) {
                      await processSeparateStreams(pendingMicChunks, []);
                      pendingMicChunks = [];
                  }
              }

              // Then process current chunks
              if (micChunks.length > 0) {
                  await processSeparateStreams(micChunks, systemChunks);
              } else {
                  // Only process system audio if mic is muted
                  await processSeparateStreams([], systemChunks);
              }
              
              micChunks = [];
              systemChunks = [];
              lastProcessTime = currentTime;

              // Restart recording
              systemRecorder.start();
              if (!isMicMuted) {
                  micRecorder.start();
              }
          }, 500);
      }
  }, TRANSCRIPTION_INTERVAL);

  // Modify the checkAuthAndUpdateUI function
  function checkAuthAndUpdateUI() {
    const isAuthenticated = userInfo !== null && userInfo.email.endsWith(`@${ALLOWED_DOMAIN}`);
    const isRecording = mediaRecorder && mediaRecorder.state === 'recording';
    
    const copyTranscriptButton = document.getElementById('copyTranscript');
    const toggleStatusButton = document.getElementById('toggleStatus');
    // Update all interactive elements
    startButton.disabled = !isAuthenticated || isRecording;
    saveAgendaButton.disabled = !isAuthenticated;
    coachButton.disabled = !isAuthenticated;
    toggleStatusButton.disabled = !isAuthenticated;
    copilotInput.disabled = !isAuthenticated;
    meetingAgenda.disabled = !isAuthenticated;
    
    if (!isAuthenticated) {
      // Add tooltips to disabled elements
      startButton.title = "Please sign in with your Techjays email to start capture";
      saveAgendaButton.title = "Please sign in with your Techjays email to save agenda";
      coachButton.title = "Please sign in with your Techjays email to use coaching";
      copilotInput.placeholder = "Please sign in with your Techjays email to use copilot";
      meetingAgenda.placeholder = "Please sign in with your Techjays email to access meeting agenda";
      
      // Add disabled styling
      [startButton, saveAgendaButton, coachButton, 
      document.getElementById('copyTranscript')].forEach(button => {
        button.classList.add('disabled-button');
      });
    } else {
      // Remove disabled styling and restore default tooltips/placeholders
      [startButton, saveAgendaButton, coachButton, 
      document.getElementById('copyTranscript')].forEach(button => {
        button.classList.remove('disabled-button');
      });
      copilotInput.placeholder = "Ask your question...";
      meetingAgenda.placeholder = "Meeting Agenda";
    }
    
    return isAuthenticated;
  }

  async function handleSignIn() {
    try {
      // Clear any existing tokens
      try {
        const existingToken = await chrome.identity.getAuthToken({ interactive: false });
        if (existingToken) {
          await chrome.identity.removeCachedAuthToken({ token: existingToken.token });
          await chrome.identity.clearAllCachedAuthTokens();
        }
      } catch (e) {
        console.log('No existing token to clear');
      }
      
      // Get new token
      const token = await chrome.identity.getAuthToken({ interactive: true });
      
      // Verify token with server
      const response = await fetch('http://127.0.0.1:8000/api/auth/google/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ token: token.token })
      });
      
      if (!response.ok) {
        const error = await response.json();
        if (response.status === 403) {
          showUnauthorizedError();
          await handleSignOut();
          return;
        }
        throw new Error(error.message || 'Authentication failed');
      }
      
      const { user } = await response.json();
      userInfo = user;
      
      // Update UI
      signInButton.style.display = 'none';
      userInfoDiv.style.display = 'flex';
      userEmailSpan.textContent = user.email;
      showStatus(`Signed in as ${user.email}`, 'capture');
      
      chrome.storage.local.set({ userInfo }, () => {
        window.location.reload();
      });
      checkAuthAndUpdateUI();
      
    } catch (error) {
      console.error('Sign in error:', error);
      showStatus(`Sign in failed: ${error.message}`, 'capture');
      showUnauthorizedError();
    }
  }

  // Add this new function to show unauthorized error
  function showUnauthorizedError() {
    // Create or update error message element
    let errorDiv = document.getElementById('auth-error');
    if (!errorDiv) {
      errorDiv = document.createElement('div');
      errorDiv.id = 'auth-error';
      errorDiv.className = 'auth-error';
      // Insert after sign in button
      signInButton.parentNode.insertBefore(errorDiv, signInButton.nextSibling);
    }
    errorDiv.textContent = UNAUTHORIZED_MESSAGE;
    
    // Show sign in button again
    signInButton.style.display = 'block';
    userInfoDiv.style.display = 'none';
  }
  
  async function handleSignOut() {
    try {
      const token = await chrome.identity.getAuthToken({ interactive: false });
      if (token) {
        // Revoke token with server
        const response = await fetch('http://127.0.0.1:8000/api/auth/revoke/', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ token: token.token })
        });
        
        if (!response.ok) {
          throw new Error('Failed to revoke token');
        }
        
        // Clear Chrome's token cache
        await chrome.identity.removeCachedAuthToken({ token: token.token });
        await chrome.identity.clearAllCachedAuthTokens();
        
        // Clear user info
        userInfo = null;
        chrome.storage.local.remove('userInfo');
        
        // Update UI
        signInButton.style.display = 'block';
        userInfoDiv.style.display = 'none';
        userEmailSpan.textContent = '';
        showStatus('Signed out successfully', 'capture');
        
        checkAuthAndUpdateUI();
      }
    } catch (error) {
      console.error('Sign out error:', error);
      showStatus(`Sign out failed: ${error.message}`, 'capture');
    }
  }
  // Check if user is already signed in
  chrome.storage.local.get('userInfo', (result) => {
    if (result.userInfo) {
      userInfo = result.userInfo;
      signInButton.style.display = 'none';
      userInfoDiv.style.display = 'flex';
      userEmailSpan.textContent = `${result.userInfo.email}`;
      showStatus(`Signed in as ${result.userInfo.email}`, 'capture');
    }
    checkAuthAndUpdateUI();
  });

  // Add event listeners for sign in/out buttons
  signInButton.addEventListener('click', handleSignIn);
  signOutButton.addEventListener('click', handleSignOut);


  // Load saved Meeting Agenda
  chrome.storage.local.get(['meetingAgenda'], (result) => {
    if (result.meetingAgenda) {
      meetingAgenda.value = result.meetingAgenda;
    }
  });

  // Save Meeting Agenda
  saveAgendaButton.addEventListener('click', () => {
    if (!checkAuthAndUpdateUI()) {
      showStatus('Please sign in to save agenda', 'capture');
      return;
    }
    // Save the original button text
    const agendaContent = meetingAgenda.value.trim();
    const originalText = saveAgendaButton.textContent;
    
    if (!agendaContent) {
      // Show error state if no content
      saveAgendaButton.textContent = 'Empty agenda';
      saveAgendaButton.classList.add('save-agenda-error');
      saveAgendaButton.disabled = true;
      
      setTimeout(() => {
        saveAgendaButton.textContent = originalText;
        saveAgendaButton.classList.remove('save-agenda-error');
        saveAgendaButton.disabled = false;
      }, 3000);
      
      showStatus('Cannot save empty agenda', 'capture');
      return;
    }

    // Update button state
    saveAgendaButton.textContent = 'Saved!';
    saveAgendaButton.classList.add('save-agenda-saved');
    saveAgendaButton.disabled = true;

    chrome.storage.local.set({ meetingAgenda: meetingAgenda.value }, () => {
      showStatus('Meeting agenda saved', 'capture');
    
    setTimeout(() => {
      saveAgendaButton.textContent = originalText;
      saveAgendaButton.classList.remove('save-agenda-saved');
      saveAgendaButton.disabled = false;
    }, 3000);
    });
  });
  async function startCapture() {
    if (!checkAuthAndUpdateUI()) {
      showStatus('Please sign in to start capture', 'capture');
      return;
    }
    
    try {
      audioContext = new (window.AudioContext || window.webkitAudioContext)();
      console.log('Audio context initialized:', {
        sampleRate: audioContext.sampleRate,
        state: audioContext.state
    });

      // Get mic stream
      micStream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: false,
          noiseSuppression: false,
          autoGainControl: false
        },
        video: false
      });

      // Get system stream
      systemStream = await navigator.mediaDevices.getDisplayMedia({
        audio: {
          echoCancellation: false,
          noiseSuppression: false,
          autoGainControl: false
        },
        video: {
          width: 1,
          height: 1
        }
      });

      systemStream.getVideoTracks().forEach(track => track.stop());

      const micRecorder = new MediaRecorder(micStream, {
        mimeType: 'audio/webm',
        audioBitsPerSecond: 128000
      });

      const systemRecorder = new MediaRecorder(systemStream, {
        mimeType: 'audio/webm',
        audioBitsPerSecond: 128000
      });

      // Separate chunks for mic and system audio
      let micChunks = [];
      let systemChunks = [];

      micRecorder.ondataavailable = (e) => {
        console.log('Mic data available:', {
            size: e.data.size,
            type: e.data.type,
            timecode: Date.now() - recordingStartTime
        });
        if (e.data && e.data.size > 0) {
            micChunks.push(e.data);
        }
    };

      systemRecorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          systemChunks.push(e.data);
        }
      };

      // Modified transcription interval
      transcriptionInterval = setInterval(async () => {
        if (systemRecorder.state === 'recording') {
          // Always stop system recorder
          systemRecorder.stop();
          
          // Only stop mic recorder if it's currently recording
          if (micRecorder.state === 'recording' && !isMicMuted) {
            micRecorder.stop();
          }

          // Process both streams
          setTimeout(async () => {
            if (micChunks.length > 0) {
              await processSeparateStreams(micChunks, systemChunks);
            } else {
              // Only process system audio if mic is muted
              await processSeparateStreams([], systemChunks);
            }
            
            micChunks = [];
            systemChunks = [];

            // Restart recording
            systemRecorder.start();
            if (!isMicMuted) {
              micRecorder.start();
            }
          }, 500);
        }
      }, TRANSCRIPTION_INTERVAL);

      // Start both recorders
      systemRecorder.start();
      if (!isMicMuted) {
        micRecorder.start();
      }
      
      recordingStartTime = Date.now();
      requestAnimationFrame(updateRecordingTimer);

      // Store references for cleanup
      mediaRecorder = {
        mic: micRecorder,
        system: systemRecorder,
        stop: () => {
          if (micRecorder.state === 'recording') micRecorder.stop();
          if (systemRecorder.state === 'recording') systemRecorder.stop();
          
          if (micStream) {
            micStream.getTracks().forEach(track => track.stop());
          }
          if (systemStream) {
            systemStream.getTracks().forEach(track => track.stop());
          }
        }
      };

      stopButton.disabled = false;
      startButton.disabled = true;
      showStatus('Capture & recording active with speaker separation.', 'capture');

    } catch (error) {
      console.error("Error starting capture:", error);
      showStatus(`Error: ${error.message}`, 'capture');
      await stopCapture();
      startButton.disabled = false;
    }
  }

  // Add these constants at the top
  const MINIMUM_AUDIO_SIZE = 50000; // 50KB minimum size
  const VOLUME_THRESHOLD = -40; // Changed from -45 to -35 dB for better silence detection
  const MIN_ACTIVE_SEGMENTS = 5; // Minimum number of segments with speech
  const SEGMENT_SIZE = 2048;
  const ACTIVE_SEGMENT_PERCENTAGE = 0.05; // At least 15% of segments should be active to consider as speech

  async function containsSpeech(blob) {
    try {
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const arrayBuffer = await blob.arrayBuffer();
        const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
        
        // Get channel data for initial analysis
        const channelData = audioBuffer.getChannelData(0);
        
        // Quick check for audio content
        let maxSample = -1;
        let minSample = 1;
        let sumSquares = 0;
        let sampledCount = 0;
        
        // Sample every 50th point for initial check
        for(let i = 0; i < channelData.length; i += 50) {
            const sample = channelData[i];
            maxSample = Math.max(maxSample, sample);
            minSample = Math.min(minSample, sample);
            sumSquares += sample * sample;
            sampledCount++;
        }

        const rms = Math.sqrt(sumSquares / sampledCount);
        console.log('Initial Audio Check:', {
            duration: audioBuffer.duration.toFixed(2) + 's',
            maxSample: maxSample.toFixed(4),
            minSample: minSample.toFixed(4),
            rms: rms.toFixed(4),
            peakToPeak: (maxSample - minSample).toFixed(4)
        });

        // If no significant audio, return early
        if (rms < 0.0001) {
            console.log('No significant audio detected');
            return false;
        }

        const numberOfChannels = audioBuffer.numberOfChannels;
        const sampleRate = audioBuffer.sampleRate;
        const samplesPerSegment = Math.floor(sampleRate * 0.1); // 100ms segments
        const numberOfSegments = Math.floor(audioBuffer.length / samplesPerSegment);
        
        let activeSegments = 0;
        let volumes = [];
        let maxSegmentVolume = -Infinity;
        
        console.log(`Detailed analysis: duration=${audioBuffer.duration.toFixed(2)}s, segments=${numberOfSegments}`);

        for (let segment = 0; segment < numberOfSegments; segment++) {
            let segmentVolume = 0;
            
            // Calculate RMS volume for this segment across all channels
            for (let channel = 0; channel < numberOfChannels; channel++) {
                const channelData = audioBuffer.getChannelData(channel);
                const startSample = segment * samplesPerSegment;
                const endSample = Math.min(startSample + samplesPerSegment, channelData.length);
                
                let sum = 0;
                // Sample every 5th point within segment for efficiency
                for (let i = startSample; i < endSample; i += 5) {
                    sum += channelData[i] * channelData[i];
                }
                segmentVolume += Math.sqrt(sum / ((endSample - startSample) / 5));
            }
            
            // Average across channels
            segmentVolume = segmentVolume / numberOfChannels;
            
            // Convert to dB
            const volumeDb = 20 * Math.log10(segmentVolume);
            
            if (volumeDb !== -Infinity && !isNaN(volumeDb)) {
                volumes.push(volumeDb);
                maxSegmentVolume = Math.max(maxSegmentVolume, volumeDb);
                
                if (volumeDb > VOLUME_THRESHOLD) {
                    activeSegments++;
                }
            }
        }

        // Calculate statistics
        const validSegments = volumes.length;
        const activePercentage = activeSegments / validSegments;
        const hasEnoughActivity = activePercentage >= ACTIVE_SEGMENT_PERCENTAGE;
        
        // Look for continuous speech segments
        let significantSpeechSegments = 0;
        let consecutiveActiveSegments = 0;
        
        for (let i = 0; i < volumes.length; i++) {
            if (volumes[i] > VOLUME_THRESHOLD) {
                consecutiveActiveSegments++;
                if (consecutiveActiveSegments >= 2) { // Reduced from 3 to 2 for better sensitivity
                    significantSpeechSegments++;
                }
            } else {
                consecutiveActiveSegments = 0;
            }
        }

        const hasContinuousSpeech = significantSpeechSegments >= MIN_ACTIVE_SEGMENTS;
        const hasSpeech = hasEnoughActivity || hasContinuousSpeech; // Changed from AND to OR for better detection

        console.log(`Analysis results:
            Active segments: ${activeSegments}/${validSegments} (${(activePercentage * 100).toFixed(1)}%)
            Significant speech segments: ${significantSpeechSegments}
            Max volume detected: ${maxSegmentVolume.toFixed(1)} dB
            Has enough activity: ${hasEnoughActivity}
            Has continuous speech: ${hasContinuousSpeech}
            Speech detected: ${hasSpeech}
        `);
        
        audioContext.close();
        return hasSpeech;

    } catch (error) {
        console.error('Error analyzing audio:', error);
        return false;
    }
}

  // Add these variables at the top
  let isProcessing = false;
  let audioQueue = {
      mic: [],
      system: []
  };

  // Modified processSeparateStreams function
  async function processSeparateStreams(micChunks, systemChunks) {
      // If already processing, add to queue
      if (isProcessing) {
          if (micChunks.length > 0) audioQueue.mic.push(...micChunks);
          if (systemChunks.length > 0) audioQueue.system.push(...systemChunks);
          console.log('Added to queue - currently processing other audio');
          return;
      }

      try {
          isProcessing = true;

          // Process current chunks
          await processAudioChunks(micChunks, systemChunks);

          // Process any queued chunks
          while (audioQueue.mic.length > 0 || audioQueue.system.length > 0) {
              const queuedMicChunks = audioQueue.mic.splice(0, audioQueue.mic.length);
              const queuedSystemChunks = audioQueue.system.splice(0, audioQueue.system.length);
              await processAudioChunks(queuedMicChunks, queuedSystemChunks);
          }

      } catch (err) {
          console.error('Transcription error:', err);
          showStatus(`Transcription error: ${err.message}`, 'transcription');
      } finally {
          isProcessing = false;
      }
  }

  // New helper function to process chunks
  async function processAudioChunks(micChunks, systemChunks) {
      // Process microphone audio (Me)
      if (micChunks.length > 0) {
          const micBlob = new Blob(micChunks, { type: 'audio/webm' });
          
          if (micBlob.size > MINIMUM_AUDIO_SIZE) {
              console.log(`Analyzing mic audio: ${(micBlob.size/1024).toFixed(2)}KB`);
              const hasSpeech = await containsSpeech(micBlob);
              
              if (hasSpeech) {
                  console.log('Speech detected in mic audio - processing transcription');
                  const micWav = await convertToWav(micBlob);
                  const micTranscript = await transcribeAudio(micWav);
                  if (micTranscript && micTranscript.trim()) {
                      transcriptionText.innerHTML += `<p class="speaker-me"><strong>Me:</strong> ${cleanTranscript(micTranscript)}</p>`;
                      showStatus('Transcription updated with speech content.', 'transcription');
                  }
              } else {
                  console.log('No speech detected in mic audio - skipping transcription');
              }
          } else {
              console.log(`Mic audio too small: ${(micBlob.size/1024).toFixed(2)}KB`);
          }
      }

      // Process system audio (Other speakers)
      if (systemChunks.length > 0) {
          const systemBlob = new Blob(systemChunks, { type: 'audio/webm' });
          
          if (systemBlob.size > MINIMUM_AUDIO_SIZE) {
              console.log(`Analyzing system audio: ${(systemBlob.size/1024).toFixed(2)}KB`);
              const hasSpeech = await containsSpeech(systemBlob);
              
              if (hasSpeech) {
                  console.log('Speech detected in system audio - processing transcription');
                  const systemWav = await convertToWav(systemBlob);
                  const systemTranscript = await transcribeAudio(systemWav);
                  if (systemTranscript && systemTranscript.trim()) {
                      transcriptionText.innerHTML += `<p class="speaker-other"><strong>Other Speakers:</strong> ${cleanTranscript(systemTranscript)}</p>`;
                      showStatus('Transcription updated with speech content.', 'transcription');
                  }
              } else {
                  console.log('No speech detected in system audio - skipping transcription');
              }
          } else {
              console.log(`System audio too small: ${(systemBlob.size/1024).toFixed(2)}KB`);
          }
      }

      transcriptionText.scrollTop = transcriptionText.scrollHeight;
  }

  // Add CSS styles for speaker separation
  const style = document.createElement('style');
  style.textContent = `
    .speaker-me {
      background-color: #e3f2fd;
      padding: 8px;
      margin: 4px 0;
      border-radius: 4px;
    }
    .speaker-other {
      background-color: #f5f5f5;
      padding: 8px;
      margin: 4px 0;
      border-radius: 4px;
    }
  `;
  document.head.appendChild(style);


  // Improved stopCapture function
  async function stopCapture() {
    try {
      // Clear transcription interval first
      if (transcriptionInterval) {
        clearInterval(transcriptionInterval);
        transcriptionInterval = null;
      }

      // Stop all media recorders
      if (mediaRecorder) {
        // Stop mic recorder if exists and is recording
        if (mediaRecorder.mic && mediaRecorder.mic.state === 'recording') {
          mediaRecorder.mic.stop();
        }
        
        // Stop system recorder if exists and is recording
        if (mediaRecorder.system && mediaRecorder.system.state === 'recording') {
          mediaRecorder.system.stop();
        }
        
        // Clear the reference
        mediaRecorder = null;
      }

      // Stop and cleanup mic stream
      if (micStream) {
        micStream.getTracks().forEach(track => {
          track.stop();
          micStream.removeTrack(track);
        });
        micStream = null;
      }

      // Stop and cleanup system stream
      if (systemStream) {
        systemStream.getTracks().forEach(track => {
          track.stop();
          systemStream.removeTrack(track);
        });
        systemStream = null;
      }

      // Close audio context
      if (audioContext) {
        await audioContext.close();
        audioContext = null;
      }

      // Clear analyzer interval if exists
      if (analyzerInterval) {
        clearInterval(analyzerInterval);
        analyzerInterval = null;
      }

      // Reset recording timer
      recordingStartTime = null;
      recordingTime.textContent = '00:00';

      // Update UI
      startButton.disabled = !userInfo;
      stopButton.disabled = true;
      
      // Show status
      showStatus('Recording stopped and all resources cleaned up');
    } catch (error) {
      console.error('Error during stop capture:', error);
      showStatus(`Error during stop: ${error.message}`);
    }
  }

  function cleanTranscript(transcript) {
    const commonFalsePositives = [
      'Thank you for watching',
      'Thanks for watching',
      'Subscribe',
      'Like and subscribe',
      'This is a continuation of the previous transcription'
    ];
    
    let cleaned = transcript;
    commonFalsePositives.forEach(phrase => {
      cleaned = cleaned.replace(new RegExp(phrase, 'gi'), '');
    });
    
    return cleaned.trim();
  }
  // Convert webm to wav
  async function convertToWav(webmBlob) {
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();

    let audioBuffer;
    // Attempt decoding multiple times if small chunks cause issues
    // This is a safeguard against decode errors for very small chunks.
    for (let i = 0; i < 3; i++) {
      try {
        const arrayBuffer = await webmBlob.arrayBuffer();
        audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
        break;
      } catch (e) {
        // If decoding fails, maybe the chunk is too small?
        // Add more chunks or wait for a bigger sample. For now, just retry.
        if (i === 2) {
          throw new Error('Unable to decode audio data after multiple attempts.');
        }
      }
    }

    const offlineContext = new OfflineAudioContext(
      audioBuffer.numberOfChannels,
      audioBuffer.length,
      audioBuffer.sampleRate
    );

    const source = offlineContext.createBufferSource();
    source.buffer = audioBuffer;
    source.connect(offlineContext.destination);
    source.start();

    const renderedBuffer = await offlineContext.startRendering();
    return audioBufferToWav(renderedBuffer);
  }
  
  async function transcribeAudio(wavBlob) {
    const formData = new FormData();
    formData.append('file', wavBlob, 'audio.wav');

    const response = await fetch('https://meeting-coach-server.replit.app/api/transcribe/', {
        method: 'POST',
        body: formData
    });

    if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(`HTTP error! status: ${response.status}, message: ${errorData.error || 'Unknown error'}`);
    }

    const data = await response.json();
    return data.text;
 }
  function audioBufferToWav(buffer) {
    const numberOfChannels = buffer.numberOfChannels;
    const sampleRate = buffer.sampleRate;
    const format = 1;
    const bitDepth = 16;

    const bytesPerSample = bitDepth / 8;
    const blockAlign = numberOfChannels * bytesPerSample;

    const dataLength = buffer.length * blockAlign;
    const bufferLength = 44 + dataLength;

    const arrayBuffer = new ArrayBuffer(bufferLength);
    const view = new DataView(arrayBuffer);

    writeString(view, 0, 'RIFF');
    view.setUint32(4, bufferLength - 8, true);
    writeString(view, 8, 'WAVE');
    writeString(view, 12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, format, true);
    view.setUint16(22, numberOfChannels, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * blockAlign, true);
    view.setUint16(32, blockAlign, true);
    view.setUint16(34, bitDepth, true);
    writeString(view, 36, 'data');
    view.setUint32(40, dataLength, true);

    let offset = 44;
    const channels = [];
    for (let i = 0; i < numberOfChannels; i++) {
      channels.push(buffer.getChannelData(i));
    }

    for (let i = 0; i < buffer.length; i++) {
      for (let channel = 0; channel < numberOfChannels; channel++) {
        const sample = Math.max(-1, Math.min(1, channels[channel][i]));
        const int16 = sample < 0 ? sample * 0x8000 : sample * 0x7FFF;
        view.setInt16(offset, int16, true);
        offset += bytesPerSample;
      }
    }

    return new Blob([arrayBuffer], { type: 'audio/wav' });
  }

  function writeString(view, offset, string) {
    for (let i = 0; i < string.length; i++) {
      view.setUint8(offset + i, string.charCodeAt(i));
    }
  }

  // Simplified updateRecordingTimer function
  function updateRecordingTimer() {
    if (!recordingStartTime) return;
    const duration = Date.now() - recordingStartTime;
    const minutes = Math.floor(duration / 60000);
    const seconds = Math.floor((duration % 60000) / 1000);
    recordingTime.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    // Continue updating as long as recordingStartTime exists
    requestAnimationFrame(updateRecordingTimer);
  }

  function showStatus(message, type = 'capture', timeout = 0) {
    const captureStatusEl = document.getElementById('captureStatus');
    const transcriptionStatusEl = document.getElementById('transcriptionStatus');
    const timeLabel = new Date().toLocaleTimeString();

    if (type === 'capture') {
      captureStatusEl.textContent += `\n[${timeLabel}] ${message}`;
      captureStatusEl.scrollTop = captureStatusEl.scrollHeight;
    } else if (type === 'transcription') {
      transcriptionStatusEl.textContent += `\n[${timeLabel}] ${message}`;
      transcriptionStatusEl.scrollTop = transcriptionStatusEl.scrollHeight;
    }
  }

  startButton.addEventListener('click', startCapture);
  stopButton.addEventListener('click', stopCapture);
  // startRecordingButton.addEventListener('click', transcribeNow);

  // Add this near your other event listeners
  document.getElementById('copyTranscript').addEventListener('click', async () => {
    if (!checkAuthAndUpdateUI()) {
      showStatus('Please sign in to copy transcript', 'transcription');
      return;
    }
    const copyButton = document.getElementById('copyTranscript');
    const originalText = copyButton.textContent;
    const transcriptionText = document.getElementById('transcriptionText').innerText;
    try {
      await navigator.clipboard.writeText(transcriptionText);
      copyButton.textContent = 'Copied!';
      copyButton.disabled = true;
      copyButton.style.backgroundColor = '#16a34a';
      setTimeout(() => {
        copyButton.textContent = originalText;
        copyButton.disabled = false;
        copyButton.style.backgroundColor = '#10b981';
      }, 2000);
      showStatus('Transcription copied to clipboard!', 'transcription');
    } catch (err) {
      showStatus('Failed to copy: ' + err.message, 'transcription');
    }
  });
// saveAgendaButtonsacs
coachButton.addEventListener('click', async () => {
  if (!checkAuthAndUpdateUI()) {
    showStatus('Please sign in to use coaching feature', 'capture');
    return;
  }
  const transcript = transcriptionText.innerText;
  const agenda = meetingAgenda.value;
  const question = copilotInput.value;

  // Validate the input fields
  if (!transcript || !agenda || !question) {
    showStatus('Missing input fields – ensure all fields are filled.', 'capture');
    return;
  }

  try {
    // Call the server endpoint
    const originalText = coachButton.textContent;
    coachButton.textContent = 'Getting Response...';
    coachButton.disabled = true;
    coachButton.classList.add('button-loading');

    const coachResponse = await getCoaching(agenda, transcript, question);

    // Format the response as Markdown
    const markdownContent = `\n### Question: ${question}\n### Response:\n${coachResponse}`;
    const renderedHTML = parseMarkdown(markdownContent);

    // Add the rendered content to the top of the responses section
    const responseHTML = `<div class="coaching-response">${renderedHTML}</div>`;
    coachingResponses.innerHTML = responseHTML + coachingResponses.innerHTML;

    showStatus('Coaching response appended.', 'capture');
  } catch (err) {
    console.error('Coaching error:', err);
    showStatus('Coaching error: ' + err.message, 'capture');
  } finally {
    // Restore button to original state
    coachButton.textContent = 'Coach';
    coachButton.disabled = false;
    coachButton.classList.remove('button-loading');
  }
});

function parseMarkdown(markdown) {
  // Replace headings
  markdown = markdown.replace(/^### (.+)$/gm, '<h3>$1</h3>');
  markdown = markdown.replace(/^## (.+)$/gm, '<h2>$1</h2>');
  markdown = markdown.replace(/^# (.+)$/gm, '<h1>$1</h1>');

  // Replace bold and italic text
  markdown = markdown.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  markdown = markdown.replace(/\*(.+?)\*/g, '<em>$1</em>');

  // Replace unordered list items
  markdown = markdown.replace(/^- (.+)$/gm, '<li>$1</li>');
  markdown = markdown.replace(/(<li>.*<\/li>)/gm, '<ul>$1</ul>'); // Wrap <li> in <ul>

  // Replace links
  markdown = markdown.replace(/\[(.+?)\]\((.+?)\)/g, '<a href="$2" target="_blank">$1</a>');

  // Replace blockquotes
  markdown = markdown.replace(/^> (.+)$/gm, '<blockquote>$1</blockquote>');

  // Replace line breaks
  markdown = markdown.replace(/\n/g, '<br>');

  return markdown;
}

  async function getCoaching(agenda, transcript, question) {
    
    const response = await fetch('https://meeting-coach-server.replit.app/api/coaching/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ agenda, transcript, question })
    });

    if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(`HTTP error! status: ${response.status}, message: ${errorData.error || 'Unknown error'}`);
    }

    const data = await response.json();
    return data.choices[0].message.content.trim();
}
console.log("Extension ID:", chrome.runtime.id);
console.log("Redirect URL:", chrome.identity.getRedirectURL());
  // End of refactored code
});