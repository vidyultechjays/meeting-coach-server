document.addEventListener('DOMContentLoaded', () => {
  // Persona chosen: "Senior Web Audio Engineer"
  // This persona focuses on reliable audio processing, clean architecture, and robust error handling.

  const startButton = document.getElementById('startCapture');
  const stopButton = document.getElementById('stopCapture');
  const startRecordingButton = document.getElementById('startRecording');
  const stopRecordingButton = document.getElementById('stopRecording');
  const status = document.getElementById('status');
  const inputMeter = document.getElementById('inputMeter');
  const recordingTime = document.getElementById('recordingTime');
  const recordingsContainer = document.getElementById('recordings');
  const transcriptionText = document.getElementById('transcriptionText');
  const meetingAgenda = document.getElementById('meetingAgenda');
  const saveAgendaButton = document.getElementById('saveAgenda');
  const copilotInput = document.getElementById('copilotInput');
  const coachButton = document.getElementById('coachButton');
  const coachingResponses = document.getElementById('coachingResponses');
  

  let userEmail = null;
  let mediaStream = null;
  let audioContext = null;
  let mediaRecorder = null;
  let analyzerInterval = null;

  let transcriptionInterval = null;  // New interval for auto-transcription

  // Accumulate chunks until we have a good amount for a stable decode
  let accumulatedChunks = [];
  let isTranscribing = false;
  let recordingStartTime = null;
  let transcriptionIntervalId = null;

  TRANSCRIPTION_INTERVAL = 30000
  TIMEOUT_TIME = 5000
  
  const signInButton = document.getElementById('signInButton');
  const signOutButton = document.getElementById('signOutButton');
  const userInfoDiv = document.getElementById('userInfo');
  const userEmailSpan = document.getElementById('userEmail');
  let userInfo = null;
  

  // Modify the checkAuthAndUpdateUI function
  function checkAuthAndUpdateUI() {
    const isAuthenticated = userInfo !== null && userInfo.email.endsWith(`@${ALLOWED_DOMAIN}`);
    const isRecording = mediaRecorder && mediaRecorder.state === 'recording';
    
    // Update all interactive elements
    startButton.disabled = !isAuthenticated || isRecording;
    saveAgendaButton.disabled = !isAuthenticated;
    coachButton.disabled = !isAuthenticated;
    document.getElementById('copyTranscript').disabled = !isAuthenticated;
    copilotInput.disabled = !isAuthenticated;
    meetingAgenda.disabled = !isAuthenticated;
    
    if (!isAuthenticated) {
      // Add tooltips to disabled elements
      startButton.title = "Please sign in with your Techjays email to start capture";
      saveAgendaButton.title = "Please sign in with your Techjays email to save agenda";
      coachButton.title = "Please sign in with your Techjays email to use coaching";
      copilotInput.placeholder = "Please sign in with your Techjays email to use copilot";
      meetingAgenda.placeholder = "Please sign in with your Techjays email to access meeting agenda";
      
      // Add disabled styling
      [startButton, saveAgendaButton, coachButton, 
      document.getElementById('copyTranscript')].forEach(button => {
        button.classList.add('disabled-button');
      });
    } else {
      // Remove disabled styling and restore default tooltips/placeholders
      [startButton, saveAgendaButton, coachButton, 
      document.getElementById('copyTranscript')].forEach(button => {
        button.classList.remove('disabled-button');
      });
      copilotInput.placeholder = "Ask your question...";
      meetingAgenda.placeholder = "Meeting Agenda";
    }
    
    return isAuthenticated;
  }

  // Add these constants at the top of your popup.js file
  const ALLOWED_DOMAIN = 'techjays.com';
  const UNAUTHORIZED_MESSAGE = 'Only Techjays employees are authorized to use this extension';

  // Modify the handleSignIn function
  async function handleSignIn() {
    try {
      // First, remove any cached tokens
      try {
        const existingToken = await chrome.identity.getAuthToken({ interactive: false });
        if (existingToken) {
          await chrome.identity.removeCachedAuthToken({ token: existingToken.token });
          await chrome.identity.clearAllCachedAuthTokens();
        }
      } catch (e) {
        console.log('No existing token to clear');
      }
      
      // Get new token with interactive sign in
      const token = await chrome.identity.getAuthToken({ interactive: true });
      
      const response = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
        headers: {
          'Authorization': `Bearer ${token.token}`
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to get user info');
      }
      
      userInfo = await response.json();
      
      // Check if the email domain matches techjays.com
      const emailDomain = userInfo.email.split('@')[1];
      
      if (emailDomain !== ALLOWED_DOMAIN) {
        // If domain doesn't match, sign out and show error
        await handleSignOut();
        showUnauthorizedError();
        return;
      }
      
      // Update UI for successful sign in
      signInButton.style.display = 'none';
      userInfoDiv.style.display = 'flex';
      userEmailSpan.textContent = `${userInfo.email}`;
      showStatus(`Signed in as ${userInfo.email}`, 'capture');
      
      chrome.storage.local.set({ userInfo }, () => {
        window.location.reload();
      });
      checkAuthAndUpdateUI();
    } catch (error) {
      console.error('Sign in error:', error);
      showStatus(`Sign in failed: ${error.message}`, 'capture');
      showUnauthorizedError();
    }
  }

  // Add this new function to show unauthorized error
  function showUnauthorizedError() {
    // Create or update error message element
    let errorDiv = document.getElementById('auth-error');
    if (!errorDiv) {
      errorDiv = document.createElement('div');
      errorDiv.id = 'auth-error';
      errorDiv.className = 'auth-error';
      // Insert after sign in button
      signInButton.parentNode.insertBefore(errorDiv, signInButton.nextSibling);
    }
    errorDiv.textContent = UNAUTHORIZED_MESSAGE;
    
    // Show sign in button again
    signInButton.style.display = 'block';
    userInfoDiv.style.display = 'none';
  }
  
  // Function to handle sign out
  async function handleSignOut() {
    try {
      const token = await chrome.identity.getAuthToken({ interactive: false });
      if (token) {
        // Revoke token with Google
        const revokeUrl = `https://accounts.google.com/o/oauth2/revoke?token=${token.token}`;
        await fetch(revokeUrl);
        
        // Remove token from Chrome's cache
        await chrome.identity.removeCachedAuthToken({ token: token.token });
        await chrome.identity.clearAllCachedAuthTokens();
        
        // Clear user info
        userInfo = null;
        chrome.storage.local.remove('userInfo');
        
        // Update UI
        signInButton.style.display = 'block';
        userInfoDiv.style.display = 'none';
        userEmailSpan.textContent = '';
        showStatus('Signed out successfully', 'capture');

        checkAuthAndUpdateUI();
      }
    } catch (error) {
      console.error('Sign out error:', error);
      showStatus(`Sign out failed: ${error.message}`, 'capture');
    }
  }
  // Check if user is already signed in
  chrome.storage.local.get('userInfo', (result) => {
    if (result.userInfo) {
      userInfo = result.userInfo;
      signInButton.style.display = 'none';
      userInfoDiv.style.display = 'flex';
      userEmailSpan.textContent = `${result.userInfo.email}`;
      showStatus(`Signed in as ${result.userInfo.email}`, 'capture');
    }
    checkAuthAndUpdateUI();
  });

  // Add event listeners for sign in/out buttons
  signInButton.addEventListener('click', handleSignIn);
  signOutButton.addEventListener('click', handleSignOut);


  // Load saved Meeting Agenda
  chrome.storage.local.get(['meetingAgenda'], (result) => {
    if (result.meetingAgenda) {
      meetingAgenda.value = result.meetingAgenda;
    }
  });

  // Save Meeting Agenda
  saveAgendaButton.addEventListener('click', () => {
    if (!checkAuthAndUpdateUI()) {
      showStatus('Please sign in to save agenda', 'capture');
      return;
    }
    chrome.storage.local.set({ meetingAgenda: meetingAgenda.value }, () => {
      showStatus('Meeting agenda saved', 'capture');
    });
  });

  // New function to process separate audio streams
  async function startCapture() {
    if (!checkAuthAndUpdateUI()) {
      showStatus('Please sign in to start capture', 'capture');
      return;
    }
    
    try {
      // Create audio context
      audioContext = new (window.AudioContext || window.webkitAudioContext)();

      // Get mic and system audio separately
      const micStream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: false,
          noiseSuppression: false,
          autoGainControl: false
        },
        video: false
      });

      const systemStream = await navigator.mediaDevices.getDisplayMedia({
        audio: {
          echoCancellation: false,
          noiseSuppression: false,
          autoGainControl: false
        },
        video: {
          width: 1,
          height: 1
        }
      });

      // Stop video track
      systemStream.getVideoTracks().forEach(track => track.stop());

      // Create separate MediaRecorders for mic and system audio
      const micRecorder = new MediaRecorder(micStream, {
        mimeType: 'audio/webm',
        audioBitsPerSecond: 128000
      });

      const systemRecorder = new MediaRecorder(systemStream, {
        mimeType: 'audio/webm',
        audioBitsPerSecond: 128000
      });

      // Separate chunks for mic and system audio
      let micChunks = [];
      let systemChunks = [];

      micRecorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          micChunks.push(e.data);
        }
      };

      systemRecorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          systemChunks.push(e.data);
        }
      };

      // Modified transcription interval
      transcriptionInterval = setInterval(async () => {
        if (micRecorder.state === 'recording' && systemRecorder.state === 'recording') {
          // Stop both recorders
          micRecorder.stop();
          systemRecorder.stop();

          // Process both streams
          setTimeout(async () => {
            await processSeparateStreams(micChunks, systemChunks);
            micChunks = [];
            systemChunks = [];

            // Restart recording
            micRecorder.start();
            systemRecorder.start();
          }, 500);
        }
      }, TRANSCRIPTION_INTERVAL);

      // Start both recorders
      micRecorder.start();
      systemRecorder.start();
      recordingStartTime = Date.now();
      requestAnimationFrame(updateRecordingTimer);

      // Store references for cleanup
      mediaRecorder = {
        mic: micRecorder,
        system: systemRecorder,
        stop: () => {
          micRecorder.stop();
          systemRecorder.stop();
        }
      };

      stopButton.disabled = false;
      startButton.disabled = true;
      showStatus('Capture & recording active with speaker separation.', 'capture');

    } catch (error) {
      console.error("Error starting capture:", error);
      showStatus(`Error: ${error.message}`, 'capture');
      await stopCapture();
      startButton.disabled = false;
    }
  }

  // New function to process separate streams
  async function processSeparateStreams(micChunks, systemChunks) {
    try {
      // Process microphone audio (Me)
      const micBlob = new Blob(micChunks, { type: 'audio/webm' });
      if (micBlob.size > 10000) {
        const micWav = await convertToWav(micBlob);
        const micTranscript = await transcribeAudio(micWav);
        if (micTranscript && micTranscript.trim()) {
          transcriptionText.innerHTML += `<p class="speaker-me"><strong>Me:</strong> ${cleanTranscript(micTranscript)}</p>`;
        }
      }

      // Process system audio (Other speakers)
      const systemBlob = new Blob(systemChunks, { type: 'audio/webm' });
      if (systemBlob.size > 10000) {
        const systemWav = await convertToWav(systemBlob);
        const systemTranscript = await transcribeAudio(systemWav);
        if (systemTranscript && systemTranscript.trim()) {
          transcriptionText.innerHTML += `<p class="speaker-other"><strong>Other Speakers:</strong> ${cleanTranscript(systemTranscript)}</p>`;
        }
      }

      transcriptionText.scrollTop = transcriptionText.scrollHeight;
      showStatus('Transcription updated with speaker separation.', 'transcription');
    } catch (err) {
      console.error('Transcription error:', err);
      showStatus(`Transcription error: ${err.message}`, 'transcription');
    }
  }

  // Add CSS styles for speaker separation
  const style = document.createElement('style');
  style.textContent = `
    .speaker-me {
      background-color: #e3f2fd;
      padding: 8px;
      margin: 4px 0;
      border-radius: 4px;
    }
    .speaker-other {
      background-color: #f5f5f5;
      padding: 8px;
      margin: 4px 0;
      border-radius: 4px;
    }
  `;
  document.head.appendChild(style);


  // Modified stopCapture function
  function stopCapture() {
    if (transcriptionInterval) {
        clearInterval(transcriptionInterval);
        transcriptionInterval = null;
    }

    if (mediaStream) {
        mediaStream.getTracks().forEach(track => track.stop());
        mediaStream = null;
    }

    if (audioContext) {
        audioContext.close();
        audioContext = null;
    }

    if (analyzerInterval) {
        clearInterval(analyzerInterval);
        analyzerInterval = null;
    }

    if (mediaRecorder) {
        if (mediaRecorder.mic) mediaRecorder.mic.stop();
        if (mediaRecorder.system) mediaRecorder.system.stop();
        mediaRecorder = null;
    }

    startButton.disabled = !userInfo;
    stopButton.disabled = true;
    showStatus('Recording stopped');
    recordingStartTime = null; // This will stop the timer
    recordingTime.textContent = '00:00';
  }

  function cleanTranscript(transcript) {
    const commonFalsePositives = [
      'Thank you for watching',
      'Thanks for watching',
      'Subscribe',
      'Like and subscribe',
      'This is a continuation of the previous transcription'
    ];
    
    let cleaned = transcript;
    commonFalsePositives.forEach(phrase => {
      cleaned = cleaned.replace(new RegExp(phrase, 'gi'), '');
    });
    
    return cleaned.trim();
  }
  // Convert webm to wav
  async function convertToWav(webmBlob) {
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();

    let audioBuffer;
    // Attempt decoding multiple times if small chunks cause issues
    // This is a safeguard against decode errors for very small chunks.
    for (let i = 0; i < 3; i++) {
      try {
        const arrayBuffer = await webmBlob.arrayBuffer();
        audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
        break;
      } catch (e) {
        // If decoding fails, maybe the chunk is too small?
        // Add more chunks or wait for a bigger sample. For now, just retry.
        if (i === 2) {
          throw new Error('Unable to decode audio data after multiple attempts.');
        }
      }
    }

    const offlineContext = new OfflineAudioContext(
      audioBuffer.numberOfChannels,
      audioBuffer.length,
      audioBuffer.sampleRate
    );

    const source = offlineContext.createBufferSource();
    source.buffer = audioBuffer;
    source.connect(offlineContext.destination);
    source.start();

    const renderedBuffer = await offlineContext.startRendering();
    return audioBufferToWav(renderedBuffer);
  }
  
  async function transcribeAudio(wavBlob) {
    const formData = new FormData();
    formData.append('file', wavBlob, 'audio.wav');

    const response = await fetch('https://meeting-coach-server.replit.app/api/transcribe/', {
        method: 'POST',
        body: formData
    });

    if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(`HTTP error! status: ${response.status}, message: ${errorData.error || 'Unknown error'}`);
    }

    const data = await response.json();
    return data.text;
 }
  function audioBufferToWav(buffer) {
    const numberOfChannels = buffer.numberOfChannels;
    const sampleRate = buffer.sampleRate;
    const format = 1;
    const bitDepth = 16;

    const bytesPerSample = bitDepth / 8;
    const blockAlign = numberOfChannels * bytesPerSample;

    const dataLength = buffer.length * blockAlign;
    const bufferLength = 44 + dataLength;

    const arrayBuffer = new ArrayBuffer(bufferLength);
    const view = new DataView(arrayBuffer);

    writeString(view, 0, 'RIFF');
    view.setUint32(4, bufferLength - 8, true);
    writeString(view, 8, 'WAVE');
    writeString(view, 12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, format, true);
    view.setUint16(22, numberOfChannels, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * blockAlign, true);
    view.setUint16(32, blockAlign, true);
    view.setUint16(34, bitDepth, true);
    writeString(view, 36, 'data');
    view.setUint32(40, dataLength, true);

    let offset = 44;
    const channels = [];
    for (let i = 0; i < numberOfChannels; i++) {
      channels.push(buffer.getChannelData(i));
    }

    for (let i = 0; i < buffer.length; i++) {
      for (let channel = 0; channel < numberOfChannels; channel++) {
        const sample = Math.max(-1, Math.min(1, channels[channel][i]));
        const int16 = sample < 0 ? sample * 0x8000 : sample * 0x7FFF;
        view.setInt16(offset, int16, true);
        offset += bytesPerSample;
      }
    }

    return new Blob([arrayBuffer], { type: 'audio/wav' });
  }

  function writeString(view, offset, string) {
    for (let i = 0; i < string.length; i++) {
      view.setUint8(offset + i, string.charCodeAt(i));
    }
  }

  // Simplified updateRecordingTimer function
  function updateRecordingTimer() {
    if (!recordingStartTime) return;
    const duration = Date.now() - recordingStartTime;
    const minutes = Math.floor(duration / 60000);
    const seconds = Math.floor((duration % 60000) / 1000);
    recordingTime.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    // Continue updating as long as recordingStartTime exists
    requestAnimationFrame(updateRecordingTimer);
  }

  function showStatus(message, type = 'capture', timeout = 0) {
    const captureStatusEl = document.getElementById('captureStatus');
    const transcriptionStatusEl = document.getElementById('transcriptionStatus');
    const timeLabel = new Date().toLocaleTimeString();

    if (type === 'capture') {
      captureStatusEl.textContent += `\n[${timeLabel}] ${message}`;
      captureStatusEl.scrollTop = captureStatusEl.scrollHeight;
    } else if (type === 'transcription') {
      transcriptionStatusEl.textContent += `\n[${timeLabel}] ${message}`;
      transcriptionStatusEl.scrollTop = transcriptionStatusEl.scrollHeight;
    }
  }

  startButton.addEventListener('click', startCapture);
  stopButton.addEventListener('click', stopCapture);
  // startRecordingButton.addEventListener('click', transcribeNow);

  // Add this near your other event listeners
  document.getElementById('copyTranscript').addEventListener('click', async () => {
    if (!checkAuthAndUpdateUI()) {
      showStatus('Please sign in to copy transcript', 'transcription');
      return;
    }
    const transcriptionText = document.getElementById('transcriptionText').innerText;
    try {
      await navigator.clipboard.writeText(transcriptionText);
      showStatus('Transcription copied to clipboard!', 'transcription');
    } catch (err) {
      showStatus('Failed to copy: ' + err.message, 'transcription');
    }
  });
// saveAgendaButtonsacs
coachButton.addEventListener('click', async () => {
  if (!checkAuthAndUpdateUI()) {
    showStatus('Please sign in to use coaching feature', 'capture');
    return;
  }
  const transcript = transcriptionText.innerText;
  const agenda = meetingAgenda.value;
  const question = copilotInput.value;

  // Validate the input fields
  if (!transcript || !agenda || !question) {
    showStatus('Missing input fields – ensure all fields are filled.', 'capture');
    return;
  }

  try {
    // Call the server endpoint
    const coachResponse = await getCoaching(agenda, transcript, question);

    // Format the response as Markdown
    const markdownContent = `\n### Question: ${question}\n### Response:\n${coachResponse}`;
    const renderedHTML = parseMarkdown(markdownContent);

    // Add the rendered content to the top of the responses section
    const responseHTML = `<div class="coaching-response">${renderedHTML}</div>`;
    coachingResponses.innerHTML = responseHTML + coachingResponses.innerHTML;

    showStatus('Coaching response appended.', 'capture');
  } catch (err) {
    console.error('Coaching error:', err);
    showStatus('Coaching error: ' + err.message, 'capture');
  }
});

function parseMarkdown(markdown) {
  // Replace headings
  markdown = markdown.replace(/^### (.+)$/gm, '<h3>$1</h3>');
  markdown = markdown.replace(/^## (.+)$/gm, '<h2>$1</h2>');
  markdown = markdown.replace(/^# (.+)$/gm, '<h1>$1</h1>');

  // Replace bold and italic text
  markdown = markdown.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  markdown = markdown.replace(/\*(.+?)\*/g, '<em>$1</em>');

  // Replace unordered list items
  markdown = markdown.replace(/^- (.+)$/gm, '<li>$1</li>');
  markdown = markdown.replace(/(<li>.*<\/li>)/gm, '<ul>$1</ul>'); // Wrap <li> in <ul>

  // Replace links
  markdown = markdown.replace(/\[(.+?)\]\((.+?)\)/g, '<a href="$2" target="_blank">$1</a>');

  // Replace blockquotes
  markdown = markdown.replace(/^> (.+)$/gm, '<blockquote>$1</blockquote>');

  // Replace line breaks
  markdown = markdown.replace(/\n/g, '<br>');

  return markdown;
}

  async function getCoaching(agenda, transcript, question) {
    
    const response = await fetch('https://meeting-coach-server.replit.app/api/coaching/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ agenda, transcript, question })
    });

    if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(`HTTP error! status: ${response.status}, message: ${errorData.error || 'Unknown error'}`);
    }

    const data = await response.json();
    return data.choices[0].message.content.trim();
}
console.log("Extension ID:", chrome.runtime.id);
console.log("Redirect URL:", chrome.identity.getRedirectURL());
  // End of refactored code
});
