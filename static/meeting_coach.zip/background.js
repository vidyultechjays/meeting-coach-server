// background.js
console.log('[Background] Service worker started');

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('[Background] Received message:', request);
  
  if (request.action === "checkTab") {
    console.log('[Background] Handling checkTab action');
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      console.log('[Background] Active tab:', tabs[0]?.id);
      sendResponse({ tabId: tabs[0]?.id });
    });
    return true;
  }
  
  // Handle mute state changes from content script
  if (request.type === 'muteStateChanged') {
    console.log('[Background] Received mute state change:', request.isMuted);
    // Broadcast the mute state to the popup
    chrome.runtime.sendMessage({
      type: 'meetMuteState',
      isMuted: request.isMuted
    }).catch(error => {
      console.log('[Background] Error broadcasting mute state (this is normal if popup is closed):', error);
    });
    
    // Send response back to content script
    sendResponse({ received: true });
  }
});

chrome.action.onClicked.addListener((tab) => {
  console.log('[Background] Extension icon clicked');
  chrome.tabs.create({
    url: 'popup.html'
  });
});