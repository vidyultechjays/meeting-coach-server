// content-script.js
console.log('Meet Mute Detector: Content script loaded');

class MeetMuteDetector {
    constructor() {
        this.observer = null;
        this.isObserving = false;
        this.lastKnownState = null;
        this.setupMessageListener();
        console.log('MeetMuteDetector initialized');
    }

    setupMessageListener() {
        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            console.log('Received message in content script:', request);
            if (request.type === 'getMuteState') {
                const muteButton = document.querySelector('[data-is-muted]');
                const isMuted = muteButton ? muteButton.getAttribute('data-is-muted') === 'true' : null;
                console.log('Current mute state:', isMuted);
                sendResponse({ isMuted });
                return true;
            }
        });
    }

    start() {
        if (this.isObserving) return;
        console.log('Starting mute detector');
        
        // Start immediate check and periodic checks
        this.checkAndNotifyMuteState();
        setInterval(() => this.checkAndNotifyMuteState(), 1000);
    }

    checkAndNotifyMuteState() {
        const muteButton = document.querySelector('[data-is-muted]');
        if (muteButton) {
            const isMuted = muteButton.getAttribute('data-is-muted') === 'true';
            if (this.lastKnownState !== isMuted) {
                this.lastKnownState = isMuted;
                console.log('Mute state changed:', isMuted);
                chrome.runtime.sendMessage({
                    type: 'muteStateChanged',
                    isMuted: isMuted
                });
            }

            if (!this.isObserving) {
                this.setupObserver(muteButton);
                this.isObserving = true;
            }
        }
    }

    setupObserver(muteButton) {
        console.log('Setting up observer');
        this.observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mutation.type === 'attributes' && mutation.attributeName === 'data-is-muted') {
                    const isMuted = mutation.target.getAttribute('data-is-muted') === 'true';
                    if (this.lastKnownState !== isMuted) {
                        this.lastKnownState = isMuted;
                        console.log('Mute state changed (observer):', isMuted);
                        chrome.runtime.sendMessage({
                            type: 'muteStateChanged',
                            isMuted: isMuted
                        });
                    }
                }
            });
        });

        this.observer.observe(muteButton, {
            attributes: true,
            attributeFilter: ['data-is-muted']
        });
    }

    stop() {
        if (this.observer) {
            this.observer.disconnect();
            this.isObserving = false;
        }
    }
}

// Create and start the detector
const detector = new MeetMuteDetector();
detector.start();

// Notify that the content script is ready
chrome.runtime.sendMessage({
    type: 'contentScriptReady'
});